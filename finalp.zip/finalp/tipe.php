<?php

$id = $_GET['id'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Tipe</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<link rel="icon" type="png" href="img/logoo.png">
<link rel="stylesheet" href="css/trans.css">
<style>
    .container {
        padding-top: 70px;
    }
</style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-light" style="background-color: #a1a0a5 !important; position: fixed; width: 100%; z-index: 1000;">
    <a class="navbar-brand" id="name" style="color: white; margin-left: 20px; cursor: pointer;">Grand Mutiara</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
            <li class="nav-item active">
                <a class="nav-link" id="home" style="color: white; margin-left: 20px;">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="about" style="color: white; margin-left: 20px;">About</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="login" style="color: white; margin-left: 20px;">Log in</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="regist" style="color: white; margin-left: 20px; margin-right:20px;">Sign in</a>
            </li>
        </ul>
    </div>
</nav>

<div id="loading" class="loading">
    <div class="spinner"></div>
    <h2 class="loading-text">GRAND MUTIARA</h2>
</div>

<form action="../paynt/payment.php" method="post">
    <div class="container">
        <h3 style="padding-top: 70px;">Pilih Tanggal</h3>
        <label for="datePicker">Tanggal:</label>
        <input type="date" id="datePicker" name="datePicker" min="" required>

        <h3>Pilih Nomor Kamar</h3>
        <label for="roomCount">No Kamar:</label>
        <select id="roomCount" name="roomCount" required>
            <?php for ($i = 1; $i <= 10; $i++) : ?>
                <?php echo "<option value=\"$i\">$i</option>"; ?>
            <?php endfor; ?>
        </select>


        <button type="submit" name="submit" id="submit">Pesan Sekarang</button>
    </div>
</form>
<script>
        // Mendapatkan tanggal hari ini
        const today = new Date();
        const dd = String(today.getDate()).padStart(2, '0');
        const mm = String(today.getMonth() + 1).padStart(2, '0'); // Januari adalah 0!
        const yyyy = today.getFullYear();

        // Format tanggal menjadi YYYY-MM-DD
        const formattedDate = yyyy + '-' + mm + '-' + dd;

        // Mengatur atribut min pada input date
        document.getElementById('datePicker').setAttribute('min', formattedDate);
</script>
    <script src="js/trans.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>
</html>