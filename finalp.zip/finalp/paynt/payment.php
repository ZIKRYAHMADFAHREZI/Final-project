<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pembayaran</title>
</head>
<body>
    <h1>Pilih pembayaran</h1>
        <li><a href="dana.php">Dana</a></li>
        <li><a href="gopay.php">Gopay</a></li>
        <li><a href="bni.php">BNI</a></li>
    </ul>
</body>
</html>