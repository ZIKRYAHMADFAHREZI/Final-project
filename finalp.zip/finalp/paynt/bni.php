<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>pembayaran</title>
</head>
<body>
    <form action="payment.php">
        <p>kirim ke : 20173913515</p>
        <p>atas nama : Asep Suparman</p>
        <input type="text">
        <label for="text">Nama pengirim</label>
        <label for="file">Bukti pembayaran</label>
        <input type="file">
        <button type="submit">Kirim</button>
    </form>
</body>
</html>